"""The OrderFulfilmentWorkflow Temporal workflow.

Workflow code must be deterministic: do all I/O inside activities, and use
``workflow.*`` helpers (``execute_activity``, ``execute_child_workflow``,
``sleep``, signals, queries) rather than calling the outside world directly.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import timedelta
from typing import Any

from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ApplicationError

with workflow.unsafe.imports_passed_through():
    from activities import (
        pick_items,
        pack_shipment,
        dispatch_shipment,
        capture_payment,
        wait_for_carrier_pickup,
        unpack_shipment,
    )
    from triggers import (
        start_order_return,
    )
    from shared import (
        WorkflowInput,
        PickItemsInput,
        PackShipmentInput,
        DispatchShipmentInput,
        CapturePaymentInput,
        WaitForCarrierPickupInput,
        UnpackShipmentInput,
        StartOrderReturnInput,
    )

DISPATCH_TIMEOUT = timedelta(seconds=60)  # Timeout for dispatch shipment activity.
PICKUP_CONFIRMATION_TIMEOUT = timedelta(seconds=43200)  # Timeout for carrier pickup confirmation.


@workflow.defn
class OrderFulfilmentWorkflow:
    """Manages the order fulfilment process from item picking to payment capture."""

    def __init__(self) -> None:
        self._status: str = "pending"
        # Read-only debug surface (safe in production: no I/O, no wall-clock).
        self._current_step: str = ""
        self._decisions_taken: list[dict[str, object]] = []
        self._triggers_fired: list[str] = []
        self._carrier_picked_up_received: bool = False

    @workflow.run
    async def run(self, arg: WorkflowInput) -> str:
        self._status = "running"
        compensations: list[tuple[Callable[..., Any], Any]] = []
        try:
            self._current_step = 'S1'
            workflow.logger.info("Running step: PickItems")
            picked_items = await workflow.execute_activity(
                pick_items,
                PickItemsInput(order_id=arg.order_id),
                start_to_close_timeout=timedelta(seconds=60),
                retry_policy=RetryPolicy(initial_interval=timedelta(seconds=1), backoff_coefficient=2, maximum_attempts=2),
            )
            self._current_step = 'S2'
            workflow.logger.info("Running step: PackShipment")
            shipment_id = await workflow.execute_activity(
                pack_shipment,
                PackShipmentInput(picked_items=picked_items),
                start_to_close_timeout=timedelta(seconds=60),
            )
            compensations.append((unpack_shipment, UnpackShipmentInput(shipment_id=shipment_id)))
            self._current_step = 'S3'
            workflow.logger.info("Running step: DispatchShipment")
            dispatch_status = await workflow.execute_activity(
                dispatch_shipment,
                DispatchShipmentInput(shipment_id=shipment_id),
                start_to_close_timeout=timedelta(seconds=60),
                retry_policy=RetryPolicy(initial_interval=timedelta(seconds=2), backoff_coefficient=2, maximum_attempts=3, non_retryable_error_types=['CarrierRejected']),
            )
            self._current_step = 'S4'
            should_dispatch_status_success = dispatch_status == 'success'  # branch condition: dispatch_status == 'success'
            if should_dispatch_status_success:
                self._decisions_taken.append({'branch': 'S4', 'predicate': "dispatch_status == 'success'", 'taken': True})
                self._current_step = 'S5'
                workflow.logger.info("Running step: CapturePayment")
                payment_id = await workflow.execute_activity(
                    capture_payment,
                    CapturePaymentInput(order_id=arg.order_id, authorization_id=arg.authorization_id),
                    start_to_close_timeout=timedelta(seconds=60),
                    retry_policy=RetryPolicy(initial_interval=timedelta(seconds=1), backoff_coefficient=2, maximum_attempts=5, non_retryable_error_types=['PaymentDeclined']),
                )
                self._current_step = 'S6'
                workflow.logger.info("Waiting for signal: carrier_picked_up")
                # Bounded wait: raises TimeoutError after pickup_confirmation_timeout, which
                # fires the saga compensations below instead of blocking forever.
                await workflow.wait_condition(lambda: self._carrier_picked_up_received, timeout=PICKUP_CONFIRMATION_TIMEOUT)
            else:
                self._decisions_taken.append({'branch': 'S4', 'predicate': "dispatch_status == 'success'", 'taken': False})
                self._current_step = 'S7'
                workflow.logger.info("Raising: CarrierRejected")
                raise ApplicationError('Workflow rejected: CarrierRejected', type='CarrierRejected', non_retryable=True)
            self._current_step = 'S8'
            workflow.logger.info("Waiting for signal: carrier_picked_up")
            # Bounded wait: raises TimeoutError after pickup_confirmation_timeout, which
            # fires the saga compensations below instead of blocking forever.
            await workflow.wait_condition(lambda: self._carrier_picked_up_received, timeout=PICKUP_CONFIRMATION_TIMEOUT)
            self._current_step = 'branch_trigger_1'
            should_when_a_shipment_is_dispatched_and_a_return_is_requested = True  # TODO: set from a real condition: when a shipment is dispatched and a return is requested
            if should_when_a_shipment_is_dispatched_and_a_return_is_requested:
                self._decisions_taken.append({'branch': 'branch_trigger_1', 'predicate': 'when a shipment is dispatched and a return is requested', 'taken': True})
                self._current_step = 'trigger_1'
                workflow.logger.info("Triggering workflow: OrderReturn")
                trigger_1_result = await workflow.execute_activity(
                    start_order_return,
                    StartOrderReturnInput(),
                    start_to_close_timeout=timedelta(seconds=60),
                )
                self._triggers_fired.append('StartOrderReturn')
            else:
                self._decisions_taken.append({'branch': 'branch_trigger_1', 'predicate': 'when a shipment is dispatched and a return is requested', 'taken': False})
        except Exception:
            for _comp_fn, _comp_arg in reversed(compensations):
                await workflow.execute_activity(
                    _comp_fn,
                    _comp_arg,
                    start_to_close_timeout=timedelta(seconds=60),
                )
            self._status = "compensated"
            raise
        self._status = "completed"
        return self._status

    @workflow.signal
    def carrier_picked_up(self) -> None:
        """Handle the 'carrier_picked_up' signal."""
        self._carrier_picked_up_received = True

    @workflow.query
    def get_fulfilment_status(self) -> str:
        """Returns the current fulfilment status."""
        return self._status

    @workflow.query
    def current_step(self) -> str:
        """The plan step currently executing (read-only debug surface)."""
        return self._current_step

    @workflow.query
    def decisions_taken(self) -> list[dict[str, object]]:
        """Every branch decision so far: branch id, predicate, and path taken."""
        return self._decisions_taken

    @workflow.query
    def triggers_fired(self) -> list[str]:
        """Cross-workflow triggers fired so far."""
        return self._triggers_fired